<!DOCTYPE html>
<html>
	<head>
		<meta charset="UTF-8">
	</head>
	<body>
		<?php
			$dbhost = "localhost";
			$dbname = "traveler";
			$dbuser = "user";
			$dbpass = "p4ssw0rd";
			$table = "customerInfo";
	
			$username=$_POST["username"];
			$firstname=$_POST["firstname"];
			$lastname=$_POST["lastname"];
			$useremail=$_POST["email"];
			$userpassword=$_POST["pw"];

			
			#connection to database
			$connection=new mysqli($dbhost,$dbuser,$dbpass, $dbname);
			
			if ($connection->connect_error){
				die ("Connection failed: ".$connection->connect_error);
			}else{
			
			echo "Connection succeeded";
			}
			if (mysqli_select_db($connection, $dbname)){
			echo "selected database";
			}
			
			
			$hash =md5($userpassword);
			
			$query="INSERT INTO customerInfo (uname, firstName, lastName, email,encryptedPass) VALUES ('$username','$firstname', '$lastname', '$useremail', '$hash');";
						
			if($result=mysqli_query($connection,$query))
			
			{
				
				echo "success";
			}else
			{

				echo "no";
				echo mysqli_error($connection);
			}
		?>
	</body>	
</html>
