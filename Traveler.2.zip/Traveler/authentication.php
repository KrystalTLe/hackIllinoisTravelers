<!DOCTYPE html>
<html>
	<head>
		<meta charset="UTF-8">
	</head>
	<body>
		<?php
			$dbhost = "localhost";
			$dbname = "traveler";
			$dbuser = "user";
			$dbpass = "p4ssw0rd";
			$table = "customerInfo";
	
			$username=$_POST["username"];
			$userpassword=$_POST["pw"];

			
			#connection to database
			$connection=new mysqli($dbhost,$dbuser,$dbpass, $dbname);
			
			if ($connection->connect_error)
			{
				die ("Connection failed: ".$connection->connect_error);
			}
			else
			{
			
				echo "Connection succeeded";
			}
			if (mysqli_select_db($connection, $dbname))
			{
				echo "selected database";
			}
			
			
			$hash =md5($password);
			
			$query="SELECT count(*) FROM uname WHERE uname='$username';";
						
			$result=mysqli_query($connection,$query);
			if($result!=0)
			{
				while($row = mysqli_fetch_assoc($query))
				{
					$db_username = $row['uname'];
					$db_password = $row['encryptedPass'];
					if(strcasecmp($username, $db_username)===0 && $hash==$db_password)
					{
					
						echo "user authenicated";
					}
					else 
					{
						echo ("error=Incorrect Password");
					}
				}		
			}
			else 
			{
				echo $result;
				echo ("That user doesn't exist");
			}
		?>
	</body>	
</html>